import { Link } from 'wouter';
import { FaDiscord, FaGithub } from 'react-icons/fa';
import { SiX } from 'react-icons/si';
import { DISCORD_INVITE, TWITTER_URL, GITHUB_URL } from '@/lib/constants';
import cobraLogo from '@assets/cobra_kai-removebg-preview.png';

const Footer = () => {
  return (
    <footer className="bg-[#121212] border-t-4 border-[#FFD700] py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-6 md:mb-0">
            <img src={cobraLogo} alt="CobraRaft Logo" className="h-12 w-auto mr-3" />
            <div>
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700]">
                COBRA<span className="text-[#E50914]">RAFT</span>
              </h3>
              <p className="text-sm text-gray-400">© {new Date().getFullYear()} CobraRaft Bot. All rights reserved.</p>
            </div>
          </div>
          
          <div className="flex flex-col items-center md:items-end">
            <div className="flex space-x-4 mb-4">
              <a 
                href={DISCORD_INVITE} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-[#FFD700] hover:text-[#E50914] transition-colors"
                aria-label="Join our Discord"
              >
                <FaDiscord className="h-6 w-6" />
              </a>
              <a 
                href={TWITTER_URL} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-[#FFD700] hover:text-[#E50914] transition-colors"
                aria-label="Follow us on X (formerly Twitter)"
              >
                <SiX className="h-6 w-6" />
              </a>
              <a 
                href={GITHUB_URL} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-[#FFD700] hover:text-[#E50914] transition-colors"
                aria-label="Visit our GitHub"
              >
                <FaGithub className="h-6 w-6" />
              </a>
            </div>
            <div className="text-sm text-gray-400">
              <Link href="/privacy" className="hover:text-[#FFD700]">Privacy Policy</Link>
              {' | '}
              <Link href="/terms" className="hover:text-[#FFD700]">Terms of Use</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
