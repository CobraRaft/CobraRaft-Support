import { useState, useEffect } from 'react';
import { Shield, Settings, Mail, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

const Privacy = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const informationCollected = [
    {
      title: "Server Information",
      content: "Server IDs, channel IDs, and role configurations necessary for bot functionality."
    },
    {
      title: "User Data",
      content: "Discord IDs, usernames, and activity metrics for moderation and rank system functionality."
    },
    {
      title: "Message Content",
      content: "For moderation purposes only - we do not store message content beyond temporary processing."
    },
    {
      title: "Usage Statistics",
      content: "Command usage and feature interaction data to improve bot functionality."
    }
  ];

  const informationUsage = [
    {
      title: "Provide Bot Functionality",
      content: "To deliver moderation, ranking, and event features."
    },
    {
      title: "Improve Services",
      content: "To analyze usage patterns and enhance bot features and performance."
    },
    {
      title: "Communication",
      content: "To respond to user inquiries and provide support."
    },
    {
      title: "Security",
      content: "To protect our services and users from abuse and unauthorized access."
    }
  ];

  const userRights = [
    {
      title: "Access",
      content: "You can request information about what data we have collected about you."
    },
    {
      title: "Correction",
      content: "You have the right to have incorrect information corrected."
    },
    {
      title: "Deletion",
      content: "You can request the deletion of your data, subject to legal requirements."
    },
    {
      title: "Opt-Out",
      content: "You can opt-out of data collection by removing the bot from your server."
    }
  ];

  return (
    <section className={`py-16 bg-[#121212] transition-opacity duration-1000 ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center mb-12">
          <div className="h-1 bg-[#FFD700] flex-grow"></div>
          <h2 className="font-['Bebas_Neue',sans-serif] text-4xl md:text-5xl text-[#FFD700] px-4">PRIVACY POLICY</h2>
          <div className="h-1 bg-[#FFD700] flex-grow"></div>
        </div>
        
        <Card className="bg-[#333333] border-l-4 border-[#FFD700] mb-12">
          <CardContent className="p-8">
            <p className="text-lg mb-4">
              At CobraRaft, we believe in striking hard when it comes to protecting your privacy. 
              This policy explains how we collect, use, and safeguard your information when you use our Discord bot.
            </p>
            <p className="italic text-gray-300">Last updated: April 2025</p>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                INFORMATION WE COLLECT
              </h3>
              <ul className="space-y-3">
                {informationCollected.map((item, index) => (
                  <li key={index} className="flex">
                    <div className="text-[#FFD700] mr-2 mt-1 flex-shrink-0">
                      <CheckCircle className="h-5 w-5" />
                    </div>
                    <div>
                      <strong>{item.title}:</strong> {item.content}
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                HOW WE USE YOUR INFORMATION
              </h3>
              <ul className="space-y-3">
                {informationUsage.map((item, index) => (
                  <li key={index} className="flex">
                    <div className="text-[#FFD700] mr-2 mt-1 flex-shrink-0">
                      <Settings className="h-5 w-5" />
                    </div>
                    <div>
                      <strong>{item.title}:</strong> {item.content}
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                DATA PROTECTION
              </h3>
              <p className="mb-4">
                We implement appropriate security measures to protect against unauthorized access, alteration, disclosure, 
                or destruction of your personal information. Your data is stored in secured environments and we regularly 
                review our collection, storage, and processing practices.
              </p>
              <p>
                Like the Cobra Kai dojo, we believe in strong protection and take the security of your data seriously. 
                We use industry-standard encryption and follow best practices to ensure your information remains safe.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                YOUR RIGHTS
              </h3>
              <ul className="space-y-3">
                {userRights.map((item, index) => (
                  <li key={index} className="flex">
                    <div className="text-[#FFD700] mr-2 mt-1 flex-shrink-0">
                      <CheckCircle className="h-5 w-5" />
                    </div>
                    <div>
                      <strong>{item.title}:</strong> {item.content}
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-12">
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                CHANGES TO THIS POLICY
              </h3>
              <p className="mb-4">
                We may update this Privacy Policy from time to time. We will notify users of any significant changes 
                through Discord announcements or our official support server.
              </p>
              <p>
                The date at the top of this Privacy Policy indicates when it was last updated. 
                We encourage you to review this policy periodically to stay informed about how we protect your information.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Privacy;
