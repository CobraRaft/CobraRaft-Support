import { useState, useEffect } from 'react';
import { Shield, XCircle, AlertCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DISCORD_INVITE, SUPPORT_EMAIL } from '@/lib/constants';

const Terms = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const prohibitedUses = [
    {
      title: "Abuse or Harassment",
      content: "Using CobraRaft to target, harass, or abuse individuals or groups."
    },
    {
      title: "Illegal Activities",
      content: "Using the bot to promote or facilitate illegal activities."
    },
    {
      title: "Exploitation",
      content: "Attempting to exploit bugs or vulnerabilities in the bot."
    },
    {
      title: "Unauthorized Access",
      content: "Attempting to gain unauthorized access to bot systems or data."
    },
    {
      title: "Reselling or Redistribution",
      content: "Reselling access to CobraRaft or its features."
    }
  ];

  return (
    <section className={`py-16 bg-gradient-to-b from-[#333333] to-[#121212] transition-opacity duration-1000 ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center mb-12">
          <div className="h-1 bg-[#FFD700] flex-grow"></div>
          <h2 className="font-['Bebas_Neue',sans-serif] text-4xl md:text-5xl text-[#FFD700] px-4">TERMS OF USE</h2>
          <div className="h-1 bg-[#FFD700] flex-grow"></div>
        </div>
        
        <Card className="bg-[#333333] border-l-4 border-[#FFD700] mb-12">
          <CardContent className="p-8">
            <p className="text-lg mb-4">
              By using CobraRaft, you agree to follow these terms with the same discipline expected 
              in the Cobra Kai dojo. These rules govern your use of our Discord bot.
            </p>
            <p className="italic text-gray-300">Last updated: April 2025</p>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                ACCEPTANCE OF TERMS
              </h3>
              <p className="mb-4">
                By adding CobraRaft to your Discord server or using any of its features, you agree to be bound 
                by these Terms of Use. If you disagree with any part of these terms, you must not use our service.
              </p>
              <p>
                These terms apply to all users, administrators, and server members who interact with CobraRaft. 
                It is your responsibility to ensure all members of your server are aware of these terms.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                PERMITTED USE
              </h3>
              <p className="mb-4">
                CobraRaft is designed for Discord server moderation, rank management, event coordination, and community engagement. 
                You are permitted to use the bot for these purposes in accordance with Discord's Terms of Service.
              </p>
              <p>
                We grant you a limited, non-exclusive, non-transferable license to use CobraRaft 
                within Discord servers where you have appropriate permissions.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                PROHIBITED USES
              </h3>
              <ul className="space-y-3">
                {prohibitedUses.map((item, index) => (
                  <li key={index} className="flex">
                    <div className="text-[#E50914] mr-2 mt-1 flex-shrink-0">
                      <XCircle className="h-5 w-5" />
                    </div>
                    <div>
                      <strong>{item.title}:</strong> {item.content}
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
          
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                LIMITATIONS OF LIABILITY
              </h3>
              <p className="mb-4">
                CobraRaft is provided "as is" without warranties of any kind, either express or implied. 
                We do not guarantee that the bot will always be available, uninterrupted, or error-free.
              </p>
              <p className="mb-4">
                We shall not be liable for any indirect, incidental, special, consequential, or punitive damages, 
                including loss of profits, data, or other intangible losses resulting from your use of the bot.
              </p>
              <p>
                In the Cobra Kai dojo and with our bot: "No such thing as a bad student, only bad teacher." 
                But even the best teachers sometimes face technical limitations.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                CHANGES TO TERMS
              </h3>
              <p className="mb-4">
                We reserve the right to modify these terms at any time. When we make changes, we will update 
                the "Last Updated" date at the top of the Terms of Use.
              </p>
              <p>
                Continued use of CobraRaft after changes to the Terms constitutes acceptance of the modified terms. 
                It is your responsibility to review these Terms periodically.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                TERMINATION
              </h3>
              <p className="mb-4">
                We reserve the right to terminate or suspend access to our bot, without prior notice or liability, for any reason, 
                including if you breach these Terms of Use.
              </p>
              <p>
                You may terminate your use of the bot at any time by removing it from your Discord server. 
                Some data may persist in our systems as outlined in our Privacy Policy.
              </p>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-12">
          <Card className="bg-[#333333] shadow-lg hover:shadow-xl transition-all duration-300">
            <CardContent className="p-6">
              <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-4 border-b border-[#FFD700] pb-2">
                CONTACT US
              </h3>
              <p className="mb-4">
                If you have any questions about these Terms of Use, please contact us through our support server 
                or via email at {SUPPORT_EMAIL}.
              </p>
              <div className="flex flex-wrap gap-4 mt-6">
                <a 
                  href={DISCORD_INVITE} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="px-6 py-2 bg-[#FFD700] text-[#121212] font-['Bebas_Neue',sans-serif] rounded-sm hover:bg-[#E50914] hover:text-white transition-colors"
                >
                  JOIN SUPPORT SERVER
                </a>
                <a 
                  href={`mailto:${SUPPORT_EMAIL}`} 
                  className="px-6 py-2 bg-[#333333] border border-[#FFD700] text-[#FFD700] font-['Bebas_Neue',sans-serif] rounded-sm hover:bg-[#FFD700] hover:text-[#121212] transition-colors"
                >
                  EMAIL SUPPORT
                </a>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Terms;
