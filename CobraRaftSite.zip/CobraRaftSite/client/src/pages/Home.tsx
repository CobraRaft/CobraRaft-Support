import { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { 
  Shield, 
  BarChart2, 
  Users, 
  Zap,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { BOT_INVITE_URL } from '@/lib/constants';
import cobraLogo from '@assets/cobra_kai-removebg-preview.png';

const Home = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const features = [
    {
      icon: <Shield className="h-10 w-10" />,
      title: "INSTANT MODERATION",
      description: "Swift, decisive action against rule-breakers. Auto-moderation that enforces your dojo's code without mercy or hesitation."
    },
    {
      icon: <BarChart2 className="h-10 w-10" />,
      title: "RANK SYSTEM",
      description: "Reward your strongest members with a belt ranking system that recognizes dedication and contribution to your server."
    },
    {
      icon: <Users className="h-10 w-10" />,
      title: "DOJO EVENTS",
      description: "Strengthen your community through automated tournaments, challenges, and events that build engagement and loyalty."
    }
  ];

  const benefits = [
    {
      icon: <Shield className="h-6 w-6" />,
      text: "Instant Moderation"
    },
    {
      icon: <BarChart2 className="h-6 w-6" />,
      text: "Rank System"
    },
    {
      icon: <Users className="h-6 w-6" />,
      text: "Dojo Events"
    },
    {
      icon: <Zap className="h-6 w-6" />,
      text: "Smart Replies"
    }
  ];

  return (
    <div className="w-full">
      <section className={`py-16 bg-gradient-to-b from-[#121212] to-[#333333] transition-opacity duration-1000 ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center mb-12">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h2 className="font-['Bebas_Neue',sans-serif] text-4xl md:text-6xl text-[#FFD700] mb-4">
                NO MERCY FOR <span className="text-[#E50914]">WEAK SERVERS</span>
              </h2>
              <p className="text-xl mb-6 leading-relaxed">
                CobraRaft is the ultimate Discord moderation bot inspired by Cobra Kai. 
                Command respect in your server with powerful tools designed for those 
                who aren't afraid to lead with strength.
              </p>
              <div className="flex flex-wrap gap-4 mb-8">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center">
                    <div className="mr-2 text-[#FFD700]">
                      {benefit.icon}
                    </div>
                    <span>{benefit.text}</span>
                  </div>
                ))}
              </div>
              <a 
                href={BOT_INVITE_URL} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-block px-8 py-3 bg-[#E50914] text-white font-['Bebas_Neue',sans-serif] text-xl rounded-sm hover:bg-[#FFD700] hover:text-[#121212] transition-colors transform hover:scale-105 duration-200"
              >
                STRIKE FIRST: ADD TO SERVER
              </a>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-[#FFD700] rounded-full blur-2xl opacity-20"></div>
                <img 
                  src={cobraLogo} 
                  alt="CobraRaft Logo" 
                  className="w-64 h-64 md:w-80 md:h-80 relative z-10" 
                />
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            {features.map((feature, index) => (
              <Card key={index} className="bg-[#333333] border-l-4 border-[#FFD700] shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                <CardContent className="p-6">
                  <div className="text-[#FFD700] mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="font-['Bebas_Neue',sans-serif] text-2xl text-[#FFD700] mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-300">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
