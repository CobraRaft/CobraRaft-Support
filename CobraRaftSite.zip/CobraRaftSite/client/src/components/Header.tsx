import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { BOT_INVITE_URL } from '@/lib/constants';
import cobraLogo from '@assets/cobra_kai-removebg-preview.png';

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  const isActiveLink = (path: string) => {
    return location === path;
  };

  return (
    <header className="py-4 border-b border-[#FFD700] shadow-md sticky top-0 z-50 bg-[#121212]">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <img src={cobraLogo} alt="CobraRaft Logo" className="h-16 w-auto" />
          <div>
            <h1 className="font-['Bebas_Neue',sans-serif] text-3xl md:text-4xl text-[#FFD700] tracking-wider">
              COBRA<span className="text-[#E50914]">RAFT</span>
            </h1>
            <p className="text-sm italic text-gray-300">Strike First. Strike Hard. No Mercy.</p>
          </div>
        </Link>
        
        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMobileMenu}
          className="md:hidden text-[#FFD700] hover:text-[#E50914] transition-colors"
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? (
            <X className="h-8 w-8" />
          ) : (
            <Menu className="h-8 w-8" />
          )}
        </button>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8 items-center">
          <Link 
            href="/" 
            className={`nav-link relative font-['Bebas_Neue',sans-serif] text-xl text-[#FFD700] hover:text-white transition-colors
              ${isActiveLink('/') ? 'after:w-full' : 'after:w-0'}`}
          >
            HOME
          </Link>
          <Link 
            href="/privacy" 
            className={`nav-link relative font-['Bebas_Neue',sans-serif] text-xl text-[#FFD700] hover:text-white transition-colors
              ${isActiveLink('/privacy') ? 'after:w-full' : 'after:w-0'}`}
          >
            PRIVACY
          </Link>
          <Link 
            href="/terms" 
            className={`nav-link relative font-['Bebas_Neue',sans-serif] text-xl text-[#FFD700] hover:text-white transition-colors
              ${isActiveLink('/terms') ? 'after:w-full' : 'after:w-0'}`}
          >
            TERMS
          </Link>
          <a 
            href={BOT_INVITE_URL} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="px-6 py-2 bg-[#E50914] text-white font-['Bebas_Neue',sans-serif] rounded-sm hover:bg-[#FFD700] hover:text-[#121212] transition-colors"
          >
            ADD TO SERVER
          </a>
        </nav>
      </div>
      
      {/* Mobile Navigation */}
      <div className={`md:hidden bg-[#333333] border-t border-[#FFD700] ${mobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="container mx-auto px-4 py-2 flex flex-col">
          <Link 
            href="/" 
            onClick={closeMobileMenu}
            className="py-3 border-b border-[#333333]/50 font-['Bebas_Neue',sans-serif] text-lg text-[#FFD700] hover:text-white transition-colors"
          >
            HOME
          </Link>
          <Link 
            href="/privacy" 
            onClick={closeMobileMenu}
            className="py-3 border-b border-[#333333]/50 font-['Bebas_Neue',sans-serif] text-lg text-[#FFD700] hover:text-white transition-colors"
          >
            PRIVACY
          </Link>
          <Link 
            href="/terms" 
            onClick={closeMobileMenu}
            className="py-3 border-b border-[#333333]/50 font-['Bebas_Neue',sans-serif] text-lg text-[#FFD700] hover:text-white transition-colors"
          >
            TERMS
          </Link>
          <a 
            href={BOT_INVITE_URL} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="mt-3 px-6 py-2 bg-[#E50914] text-white font-['Bebas_Neue',sans-serif] rounded-sm text-center hover:bg-[#FFD700] hover:text-[#121212] transition-colors"
          >
            ADD TO SERVER
          </a>
        </div>
      </div>

      <style jsx>{`
        .nav-link::after {
          content: '';
          position: absolute;
          height: 2px;
          bottom: -2px;
          left: 0;
          background-color: #FFD700;
          transition: width 0.3s ease;
        }
        .nav-link:hover::after {
          width: 100%;
        }
      `}</style>
    </header>
  );
};

export default Header;
