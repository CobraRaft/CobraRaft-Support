const CobraLogo = () => {
  return (
    <svg
      width="100%"
      height="100%"
      viewBox="0 0 200 200"
      xmlns="http://www.w3.org/2000/svg"
      className="cobra-logo"
    >
      <defs>
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      <circle cx="100" cy="100" r="95" fill="#121212" stroke="#FFD700" strokeWidth="2" />
      <g filter="url(#glow)">
        <path
          d="M100 25C75 25 50 35 35 60C20 85 25 115 40 135C55 155 75 165 100 165C125 165 145 155 160 135C175 115 180 85 165 60C150 35 125 25 100 25Z"
          fill="#FFD700"
        />
        <path
          d="M100 40C80 40 65 50 55 65C45 80 45 100 55 115C65 130 80 140 100 140C120 140 135 130 145 115C155 100 155 80 145 65C135 50 120 40 100 40Z"
          fill="#121212"
        />
        <path
          d="M100 55C90 55 85 60 80 70C75 80 75 90 80 100C85 110 90 115 100 115C110 115 115 110 120 100C125 90 125 80 120 70C115 60 110 55 100 55Z"
          fill="#E50914"
        />
        <path
          d="M90 75L110 75"
          stroke="#FFD700"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path
          d="M100 140C100 140 100 170 85 185"
          stroke="#FFD700"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <path
          d="M100 140C100 140 100 170 115 185"
          stroke="#FFD700"
          strokeWidth="10"
          strokeLinecap="round"
        />
      </g>
    </svg>
  );
};

export default CobraLogo;
