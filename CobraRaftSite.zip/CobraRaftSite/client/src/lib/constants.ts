export const BOT_CLIENT_ID = "1358377074657853510";

// Social links
export const DISCORD_INVITE = "https://discord.gg/4r2uUDXfAq";
export const TWITTER_URL = "https://x.com/CobraRaft";
export const GITHUB_URL = "https://github.com/CobraRaft";
export const SUPPORT_EMAIL = "cobraraft.com@gmail.com";

// Bot invite URL with proper scopes
export const BOT_INVITE_URL = "https://discord.com/oauth2/authorize?client_id=1358377074657853510&permissions=8&integration_type=0&scope=applications.commands+bot";
